go get "github.com/ethereum/go-ethereum/ethclient"
go build -o bin/application --tags linux