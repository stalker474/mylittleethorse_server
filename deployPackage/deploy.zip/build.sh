go get "github.com/gorilla/mux"
go get "github.com/ethereum/go-ethereum"
go build -o bin/application --tags linux