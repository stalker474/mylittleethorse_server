// +build linux

package main

var ipc = "/home/antonpossylkine/.ethereum/geth.ipc"
