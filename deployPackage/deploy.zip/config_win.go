// +build windows

package main

var ipc = "\\\\.\\pipe\\geth.ipc"
